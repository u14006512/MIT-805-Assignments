
== Feature 1 - Crimes per Year
python '1. Crimes per Year.mr.py' /home/francois/Source/smaller.csv > './Results/1. Crimes per Year.txt'
python '1. Crimes per Year.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/1. Crimes per Year.txt'

== Feature 2 - Crimes per District
python '2. Crimes per District.mr.py' /home/francois/Source/smaller.csv > './Results/2. Crimes per District.txt'
python '2. Crimes per District.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/2. Crimes per District.txt'

== Feature 3 - Crimes per District per Year
python '3. Crimes per District per Year.mr.py' /home/francois/Source/smaller.csv > './Results/3. Crimes per District per Year.txt'
python '3. Crimes per District per Year.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/3. Crimes per District per Year.txt'

== Feature 4 - Crimes per Type
python '4. Crimes per Type.mr.py' /home/francois/Source/smaller.csv > './Results/4. Crimes per Type.txt'
python '4. Crimes per Type.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/4. Crimes per Type.txt'

== Feature 5 - Crimes per Year per District per Type
python '5. Crimes per Year per District per Type.mr.py' /home/francois/Source/smaller.csv > './Results/5. Crimes per Year per District per Type.txt'
python '5. Crimes per Year per District per Type.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/5. Crimes per Year per District per Type.txt'

== Feature 6 - Arrests in Total
python '6. Arrests in Total.mr.py' /home/francois/Source/smaller.csv > './Results/6. Arrests in Total.txt'
python '6. Arrests in Total.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/6. Arrests in Total.txt'

== Feature 7 - Arrests per Year
python '7. Arrests per Year.mr.py' /home/francois/Source/smaller.csv > './Results/7. Arrests per Year.txt'
python '7. Arrests per Year.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/7. Arrests per Year.txt'

== Arrests Likelihood Table Extractor
python 'Arrests Likelihood Table Extractor.mr.py' /home/francois/Source/smaller.csv > './Results/Arrests Likelihood Table.txt'
python 'Arrests Likelihood Table Extractor.mr.py' /home/francois/Source/Crimes_-_2001_to_present.csv > './Results/Arrests Likelihood Table.txt'
